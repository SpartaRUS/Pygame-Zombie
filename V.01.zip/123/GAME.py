import pygame, sys
from Zombie2 import *
pygame.init()
WIDTH, HEIGHT = 1280, 720
Permission = (WIDTH, HEIGHT)
screen = pygame.display.set_mode((Permission))
pygame.display.set_caption("Герои 5 2D")
icon = pygame.image.load('images/icon.png')
pygame.display.set_icon(icon)
background_image = pygame.image.load('images/display.png')

#sound1 = pygame.mixer.music.load('saund/ZombieApocalypse.mp3') #Босс
sound2 = pygame.mixer.music.load('saund/ZombieTheme.mp3')
#sound3 = pygame.mixer.music.load('saund/ZombieReckoning.mp3') #Босс2
#sound4 = pygame.mixer.music.load('saund/Zombie.mp3')
#sound5 = pygame.mixer.music.load('saund/ZombieCarnage.mp3')
pygame.mixer.music.set_volume(0.3)
pygame.mixer.music.play(-1,0.0)
clock = pygame.time.Clock()

zomb = zombie_model(screen)
keys = {'left': False, 'right': False, 'up' : False, 'collideUP' : False, 'bullet' : False}
saund = {'first' : True, 'second' : True, 'third': True, 'fourth' : True, 'fifth': True}
plaingGame = True
while plaingGame:
    clock.tick(30)
    pygame.display.update()
    screen.blit(background_image, (0, 0))
    zomb.output()

    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_w, pygame.K_UP, pygame.K_SPACE):
                keys['up'] = True
            if event.key in (pygame.K_d, pygame.K_RIGHT):
                keys['right'] = True
            if event.key in (pygame.K_a, pygame.K_LEFT):
                keys['left'] = True 
            if event.key in (pygame.K_s, pygame.K_DOWN):
                keys['bullet'] = True
        if event.type == pygame.KEYUP:
            if event.key in (pygame.K_a, pygame.K_LEFT):
                keys['left'] = False
            if event.key in (pygame.K_d, pygame.K_RIGHT):
                keys['right'] = False
            if event.key in (pygame.K_w, pygame.K_UP, pygame.K_SPACE):
                keys['up'] = False
            if event.key in (pygame.K_s, pygame.K_DOWN):
                keys['bullet'] = False
    zomb.apdate_zomb(keys)
    zomb.collide()
    if live['Pipl_lv1'] == False:
        if saund['fifth']:
            sound5 = pygame.mixer.music.load('saund/ZombieCarnage.mp3')
            pygame.mixer.music.play(-1,0.0)
            saund['fifth'] = False
        if live['Pipl_lv2'] == False:
            if saund['first']:
                sound1 = pygame.mixer.music.load('saund/ZombieApocalypse.mp3')
                pygame.mixer.music.play(-1,0.0)
                saund['first'] = False
