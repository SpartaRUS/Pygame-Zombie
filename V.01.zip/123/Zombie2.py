import pygame
SpeedDown = 5
factor = {'jump': False, 'platform' : False}
characteristics = {'Jump_height' : 10, 'time_shot' : 120}
bullet = pygame.image.load('images/Bullet.png')
bullets = []
coordinatesX = []
coordinatesY = []
StartCoordinatesX = []
StartCoordinatesY = []
speed = 100
zombie_speed = 6
Jump_height = 20
live = {'Pipl_lv1' : True, 'Pipl_lv2' : False}
Level = {'Level_1' : True, 'Level_2' : False}
class zombie_model():

    def __init__(self, screen):
        self.screen = screen
        if live['Pipl_lv1']:
            self.Zombie = pygame.image.load('images/ZombieX4.png')
        if live['Pipl_lv1'] == False:
            self.Zombie = pygame.image.load('images/ZombieX4_lv2.png')
        self.ZombieRect = self.Zombie.get_rect()
        self.ZombieRect.x = 300
        self.ZombieRect.y = 500
        if Level['Level_1']:
            self.platform = pygame.image.load('images/platformX3.png')
            self.platformRect = self.platform.get_rect()
            self.platformRect.x = 400
            self.platformRect.y = 560
        if Level['Level_1']:
            self.platform1 = pygame.image.load('images/platformX3.png')
            self.platformRect1 = self.platform1.get_rect()
            self.platformRect1.x = 500
            self.platformRect1.y = 460
        if Level['Level_1']:
            self.platform2 = pygame.image.load('images/platformX3.png')
            self.platformRect2 = self.platform2.get_rect()
            self.platformRect2.x = 600
            self.platformRect2.y = 360
        if Level['Level_1']:
            self.Bottom_platform = pygame.image.load('images/Bottom_platform.png')
            self.Bottom_platformRect = self.Bottom_platform.get_rect()
            self.Bottom_platformRect.x = 0
            self.Bottom_platformRect.y = 672
        if Level['Level_1']:
            self.ZamokX3 = pygame.image.load('images/ZamokX3.png')
            self.ZamokX3Rect = self.ZamokX3.get_rect()
            self.ZamokX3Rect.x = 0
            self.ZamokX3Rect.y = 288
        if Level['Level_1']:
            self.Tank = pygame.image.load('images/Tank.png')
            self.TankRect = self.Tank.get_rect()
            self.TankRect.x = 700
            self.TankRect.y = 268
        if Level['Level_1']:
            self.Pipl = pygame.image.load('images/PiplX4.png')
            self.PiplRect = self.Pipl.get_rect()
            self.PiplRect.x = 750
            self.PiplRect.y = 632
        self.win = pygame.image.load('images/Win.png')
        global platforms
        platforms = (self.platformRect, self.platformRect1, self.platformRect2, self.Bottom_platformRect)

    def output(self):
        self.screen.blit(self.Tank, self.TankRect)
        self.screen.blit(self.ZamokX3, self.ZamokX3Rect)
        if live['Pipl_lv1'] or live['Pipl_lv2']:
            self.screen.blit(self.Pipl, self.PiplRect)
        self.screen.blit(self.Zombie, self.ZombieRect)
        self.screen.blit(self.platform, self.platformRect)
        self.screen.blit(self.platform1, self.platformRect1)
        self.screen.blit(self.platform2, self.platformRect2)
        self.screen.blit(self.Bottom_platform, self.Bottom_platformRect)
        if live['Pipl_lv1'] == False and live['Pipl_lv2'] == False:
            self.screen.blit(self.win, (0, 0))


    def apdate_zomb(self, keys):
        if factor['jump'] == False:
            if factor['platform'] == False:
                self.ZombieRect.y += SpeedDown
        if keys['right']:
            self.ZombieRect.x += zombie_speed
            if live['Pipl_lv1'] == False:
                self.Zombie = pygame.image.load('images/ZombieX4_lv2.png')
        if keys['left']:
            self.ZombieRect.x -= zombie_speed
            if live['Pipl_lv1'] == False:
                self.Zombie = pygame.image.load('images/ZombieX4_lv2_left.png')
        if self.ZombieRect.right >= 1280:
            keys['right'] = False
        if self.ZombieRect.x <= 1:
            keys['left'] = False
        if keys['up']:
                if factor['platform']:
                    if keys['collideUP'] == False:
                        characteristics['Jump_height'] = Jump_height
                        factor['jump'] = True
        if factor['jump']:
            self.ZombieRect.y -= (characteristics['Jump_height'] ** 2)/32
            characteristics['Jump_height'] -= 1
            if characteristics['Jump_height'] <= 0:
                factor['jump'] = False
        for platform in platforms:
            collide = pygame.Rect.colliderect(platform, self.ZombieRect)
            if collide:
                if self.ZombieRect.top < platform.bottom and self.ZombieRect.top > platform.bottom -11:
                    factor['platform'] = False
                elif self.ZombieRect.right > platform.left and self.ZombieRect.right < platform.left + 11:
                    factor['platform'] = False
                elif self.ZombieRect.left < platform.right and self.ZombieRect.left > platform.right - 11:
                    factor['platform'] = False
            if collide == False:
                factor['platform'] = False

        if live['Pipl_lv1'] or live['Pipl_lv2']:
            if characteristics['time_shot'] <= 0:
                bullets.clear()
                coordinatesX.clear()
                coordinatesY.clear()
                StartCoordinatesX.clear()
                StartCoordinatesY.clear()
                bullets.append(bullet.get_rect(center=(self.PiplRect.x +16, self.PiplRect.y + 15)))
                coordinatesX.append(self.ZombieRect.x)
                coordinatesY.append(self.ZombieRect.y)
                StartCoordinatesX.append(self.PiplRect.x +16)
                StartCoordinatesY.append(self.PiplRect.y + 15)
                characteristics['time_shot'] = 60
            characteristics['time_shot'] -= 1
        if bullets:
            for el in bullets:
                for coordX in coordinatesX:
                    for startX in StartCoordinatesX:
                        for coordY in coordinatesY:
                            for startY in StartCoordinatesY:
                                tripX = coordX - startX
                                trip_stepX = tripX // speed 
                                if startY >= coordY:
                                    tripY = startY - coordY
                                    trip_stepY = tripY / trip_stepX
                                else:
                                    tripY = coordY - startY
                                    trip_stepY = -(tripY / trip_stepX)
                                if tripX > 100 or tripX < -100:
                                    if startX > coordX:
                                        el.x -= speed
                                        el.y += trip_stepY
                                    else:
                                        el.x += speed
                                        el.y -= trip_stepY
                                else:
                                    bullets.clear()
                self.screen.blit(bullet, (el.x, el.y))

    def collide(self):
        for platform in platforms:
            collide = pygame.Rect.colliderect(platform, self.ZombieRect)
            if collide:
                if self.ZombieRect.bottom > platform.top and self.ZombieRect.bottom < platform.top +11:
                    self.ZombieRect.bottom = platform.top +1
                    factor['platform'] = True
                if self.ZombieRect.top < platform.bottom and self.ZombieRect.top > platform.bottom -11:
                    self.ZombieRect.top = platform.bottom
                elif self.ZombieRect.right > platform.left and self.ZombieRect.right < platform.left + 11:
                    self.ZombieRect.right = platform.left
                elif self.ZombieRect.left < platform.right and self.ZombieRect.left > platform.right - 11:
                    self.ZombieRect.left = platform.right
        collide = pygame.Rect.colliderect(self.TankRect, self.ZombieRect)
        if collide:
            if self.ZombieRect.bottom > self.TankRect.top and self.ZombieRect.bottom < self.TankRect.top +11:
                        self.ZombieRect.bottom = self.TankRect.top +1
                        factor['platform'] = True
        for platform in platforms:
            for el in bullets:
                collide = pygame.Rect.colliderect(platform, el)
                if collide:
                    bullets.clear()
        self.dead()
    def dead(self):
        if live['Pipl_lv1']:
            live_1 = pygame.Rect.colliderect(self.PiplRect, self.ZombieRect)
        if live['Pipl_lv1']:
            if live_1:
                live['Pipl_lv1'] = False
                live['Pipl_lv2'] = True
                TransX = self.ZombieRect.x
                TransY = self.ZombieRect.y
                self.Zombie = pygame.image.load('images/ZombieX4_lv2.png')
                self.ZombieRect = self.Zombie.get_rect()
                self.ZombieRect.x = TransX -20
                self.ZombieRect.y = TransY -32
                global zombie_speed
                zombie_speed = 10
                global Jump_height
                Jump_height = 25
                global SpeedDown
                SpeedDown = 8
                self.Pipl = pygame.image.load('images/pipl_lv2.png')
                self.PiplRect = self.Pipl.get_rect()
                self.PiplRect.x = 1100
                self.PiplRect.y = 208
        if live['Pipl_lv2']:
            live_1 = pygame.Rect.colliderect(self.PiplRect, self.ZombieRect)
        if live['Pipl_lv2']:
            if live_1:
                live['Pipl_lv2'] = False
                

